/**
 * 
 */
package com.elsevier.taskmgr.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Samir
 *
 */
@Entity
@Table(name = "tasks")
public class TaskManager {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "title", nullable = false)
	private String title;
	@Column(name = "desc", nullable = false)
	private String description;
	@Column(name = "finishflag", nullable = false)
	private boolean finish;
	
	public TaskManager() {

    }
	/**
	 * @param id
	 * @param title
	 * @param description
	 * @param flag
	 */
	public TaskManager(String title, String description, boolean finish) {
		super();
		this.title = title;
		this.description = description;
		this.finish = finish;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isFinish() {
		return finish;
	}
	public void setFinish(boolean finish) {
		this.finish = finish;
	}
	
	
	
}
