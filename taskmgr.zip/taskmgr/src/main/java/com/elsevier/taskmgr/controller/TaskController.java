/**
 * 
 */
package com.elsevier.taskmgr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elsevier.taskmgr.exception.ResourceNotFoundException;
import com.elsevier.taskmgr.model.TaskManager;
import com.elsevier.taskmgr.repository.TaskRepository;

/**
 * @author Samir
 *
 */
@RestController
@RequestMapping("/api/v1")
public class TaskController {

	@Autowired
	private TaskRepository taskRepository;

	@PostMapping("/tasks")
	public ResponseEntity<TaskManager> createTasks(@RequestBody TaskManager taskMgr) {
		return ResponseEntity.ok(taskRepository.save(taskMgr));

	}

	@GetMapping("/tasks")
	public ResponseEntity<List<TaskManager>> getAllTasks() {
		return ResponseEntity.ok(taskRepository.findAll());
	}
	
	@GetMapping("/tasks/{id}")
    public ResponseEntity < TaskManager > getEmployeeById(@PathVariable(value = "id") Long taskId)
    throws ResourceNotFoundException {
        TaskManager tskMgr = taskRepository.findById(taskId)
            .orElseThrow(() -> new ResourceNotFoundException("Task not found for this id :: " + taskId));
        return ResponseEntity.ok().body(tskMgr);
    }
}
